package net.chabab.gestionanalyse.entites;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Builder
@Entity
public class Analyse {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nom;
    private String description;

    @OneToMany(mappedBy = "analyse", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Epreuve> epreuves = new ArrayList<>();  // Default initialization to avoid null issues
}
