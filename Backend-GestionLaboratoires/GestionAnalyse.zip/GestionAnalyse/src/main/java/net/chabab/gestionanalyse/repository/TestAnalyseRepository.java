package net.chabab.gestionanalyse.repository;

import net.chabab.gestionanalyse.entites.TestAnalyse;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TestAnalyseRepository extends JpaRepository<TestAnalyse, Long> {
}
