package net.chabab.gestionanalyse.repository;

import net.chabab.gestionanalyse.entites.Epreuve;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EpreuveRepository extends JpaRepository<Epreuve, Long> {
}
