package net.chabab.gestionanalyse.dtos;

import jakarta.validation.constraints.NotBlank;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Builder
public class AnalyseDTO {
    private Long id;

    @NotBlank(message = "Nom is required")
    private String nom;

    @NotBlank(message = "Description is required")
    private String description;

    // Ensure that the list is never null
    private List<EpreuveDTO> epreuves = new ArrayList<>();
}
